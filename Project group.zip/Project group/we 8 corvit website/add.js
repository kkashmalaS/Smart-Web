// Get all the toggle buttons and answer sections
const toggleButtons = document.querySelectorAll('#toggleButton');
const answerSections = document.querySelectorAll('#answerSection');

// Loop through each toggle button and add an event listener
toggleButtons.forEach((button, index) => {
  button.addEventListener('click', () => {
    // Toggle the visibility of the corresponding answer section
    answerSections[index].classList.toggle('hidden');

    // Get the button icon element
    const buttonIcon = button.querySelector('#buttonIcon');

    // Toggle the button icon between '+' and '-'
    buttonIcon.textContent = buttonIcon.textContent === '+' ? '-' : '+';
  });
});

// Get all the toggle buttons and answer sections
// const toggleButtons = document.querySelectorAll('#toggleButton');
// const answerSections = document.querySelectorAll('#answerSection');

// // Loop through each toggle button and add an event listener
// toggleButtons.forEach((button, index) => {
//   button.addEventListener('click', () => {
//     // Toggle the visibility of the corresponding answer section
//     answerSections[index].classList.toggle('hidden');

//     // Get the button icon element
//     const buttonIcon = button.querySelector('#buttonIcon');

//     // Toggle the button icon between '+' and '-'
//     buttonIcon.textContent = buttonIcon.textContent === '+' ? '-' : '+';
//   });
// });