const hireBtn = document.getElementById('hireBtn');
const hireDropdown = document.getElementById('hireDropdown');
const skypeBtn = document.getElementById('skypeBtn');
const skypeDropdown = document.getElementById('skypeDropdown');

hireBtn.addEventListener('click', () => {
  hireDropdown.classList.toggle('hidden');
});

skypeBtn.addEventListener('click', () => {
  skypeDropdown.classList.toggle('hidden');
});

// Close the dropdown when clicking outside
document.addEventListener('click', (event) => {
  if (!event.target.matches('#hireBtn, #hireBtn *, #skypeBtn, #skypeBtn *')) {
    hireDropdown.classList.add('hidden');
    skypeDropdown.classList.add('hidden');
  }
});
