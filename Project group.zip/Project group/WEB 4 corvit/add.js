// Get all the slide elements
const slides = document.querySelectorAll('.slide');

// Set the initial slide index
let currentSlide = 0;

// Function to show the current slide
function showSlide(n) {
  // Reset all slides to inactive
  slides.forEach(slide => slide.classList.remove('active'));

  // Set the current slide to active
  slides[n].classList.add('active');
}

// Function to move to the next slide
function nextSlide() {
  currentSlide = (currentSlide + 1) % slides.length;
  showSlide(currentSlide);
}

// Function to move to the previous slide
function prevSlide() {
  currentSlide = (currentSlide - 1 + slides.length) % slides.length;
  showSlide(currentSlide);
}

// Show the initial slide
showSlide(currentSlide);

// Set an interval to automatically move to the next slide every 5 seconds
setInterval(nextSlide, 5000);
<!--- drop down men-->




const hireBtn = document.getElementById('hireBtn');
const hireDropdown = document.getElementById('hireDropdown');
const skypeBtn = document.getElementById('skypeBtn');
const skypeDropdown = document.getElementById('skypeDropdown');

hireBtn.addEventListener('click', () => {
  hireDropdown.classList.toggle('hidden');
});

skypeBtn.addEventListener('click', () => {
  skypeDropdown.classList.toggle('hidden');
});

// Close the dropdown when clicking outside
document.addEventListener('click', (event) => {
  if (!event.target.matches('#hireBtn, #hireBtn *, #skypeBtn, #skypeBtn *')) {
    hireDropdown.classList.add('hidden');
    skypeDropdown.classList.add('hidden');
  }
});

<!---->
function navigateToLink(url, dropdownId) {
  if (url) {
    window.open(url, '_blank');
  } else {
    const dropdown = document.getElementById(`${dropdownId}Dropdown`);
    dropdown.focus();
  }
}








